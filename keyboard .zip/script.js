const typingBox = document.getElementById("typingBox");

const keyboard = document.getElementById("keyboard");
const emojiPanel = document.getElementById("emojiPanel");

const emojiKey = document.getElementById("emojiKey");
const emojiToolbar = document.getElementById("emojiToolbar");
const emojiBack = document.getElementById("emojiBack");

const shiftKey = document.getElementById("shiftKey");
const backspaceKey = document.getElementById("backspaceKey");

const spaceKey = document.getElementById("spaceKey");
const enterKey = document.getElementById("enterKey");
const periodKey = document.getElementById("periodKey");

const numberKey = document.getElementById("numberKey");

const languageKey = document.getElementById("languageKey");
const languageBtn = document.getElementById("languageBtn");
const languageMenu = document.getElementById("languageMenu");
const languageSearch = document.getElementById("languageSearch");

const clearBtn = document.getElementById("clearBtn");
const copyBtn = document.getElementById("copyBtn");
const voiceBtn = document.getElementById("voiceBtn");

let shiftActive = false;
let emojiVisible = false;
let numberMode = false;
let selectedLanguage = "en-US";

const alphabet = [
  "q","w","e","r","t","y","u","i","o","p",
  "a","s","d","f","g","h","j","k","l",
  "z","x","c","v","b","n","m"
];

const numbers = [
  "1","2","3","4","5","6","7","8","9","0",
  "-","/","@",":",";",",","?","!","#","$",
  "%","&","*","(",")"
];

/* ================= INSERT ================= */

function insertText(text) {

  typingBox.focus();

  const start = typingBox.selectionStart ?? typingBox.value.length;
  const end = typingBox.selectionEnd ?? start;

  typingBox.value =
    typingBox.value.substring(0, start) +
    text +
    typingBox.value.substring(end);

  const position = start + text.length;

  typingBox.setSelectionRange(position, position);
}

/* ================= NORMAL KEYS ================= */

function setupKeys() {

  document.querySelectorAll(".key").forEach((button, index) => {

    button.onclick = () => {

      let value = button.textContent;

      if (shiftActive && !numberMode) {
        value = value.toUpperCase();
      }

      insertText(value);

      if (shiftActive) {
        shiftActive = false;
        shiftKey.classList.remove("active");
      }
    };

  });
}

setupKeys();

/* ================= SHIFT ================= */

shiftKey.onclick = () => {

  if (numberMode) return;

  shiftActive = !shiftActive;

  shiftKey.classList.toggle(
    "active",
    shiftActive
  );
};

/* ================= BACKSPACE ================= */

backspaceKey.onclick = () => {

  typingBox.focus();

  const start = typingBox.selectionStart;
  const end = typingBox.selectionEnd;

  if (start !== end) {

    typingBox.value =
      typingBox.value.substring(0, start) +
      typingBox.value.substring(end);

    typingBox.setSelectionRange(start, start);

    return;
  }

  if (start > 0) {

    typingBox.value =
      typingBox.value.substring(0, start - 1) +
      typingBox.value.substring(start);

    typingBox.setSelectionRange(
      start - 1,
      start - 1
    );
  }
};

/* ================= SPACE ================= */

spaceKey.onclick = () => insertText(" ");

/* ================= PERIOD ================= */

periodKey.onclick = () => insertText(".");

/* ================= ENTER ================= */

enterKey.onclick = () => insertText("\n");

/* ================= EMOJI ================= */

function showEmoji() {

  emojiVisible = true;

  keyboard.style.display = "none";
  emojiPanel.classList.add("show");

  typingBox.focus();
}

function showKeyboard() {

  emojiVisible = false;

  emojiPanel.classList.remove("show");
  keyboard.style.display = "block";

  typingBox.focus();
}

function toggleEmoji() {

  if (emojiVisible) {
    showKeyboard();
  } else {
    showEmoji();
  }
}

emojiKey.onclick = toggleEmoji;
emojiToolbar.onclick = toggleEmoji;
emojiBack.onclick = showKeyboard;

/* ================= EMOJI BUTTONS ================= */

document
  .querySelectorAll(".emoji-grid button")
  .forEach(button => {

    button.onclick = () => {
      insertText(button.textContent);
    };

  });

/* ================= LANGUAGE ================= */

function openLanguageMenu() {

  languageMenu.classList.add("show");

  languageSearch.value = "";

  languageSearch.focus();
}

function closeLanguageMenu() {

  languageMenu.classList.remove("show");
}

languageBtn.onclick = (event) => {

  event.stopPropagation();

  if (languageMenu.classList.contains("show")) {
    closeLanguageMenu();
  } else {
    openLanguageMenu();
  }
};

languageKey.onclick = (event) => {

  event.stopPropagation();

  if (languageMenu.classList.contains("show")) {
    closeLanguageMenu();
  } else {
    openLanguageMenu();
  }
};

/* ================= LANGUAGE SEARCH ================= */

languageSearch.oninput = () => {

  const search =
    languageSearch.value
      .toLowerCase()
      .trim();

  document
    .querySelectorAll(".language-option")
    .forEach(option => {

      const text =
        option.textContent.toLowerCase();

      option.style.display =
        text.includes(search)
          ? "block"
          : "none";
    });
};

/* ================= LANGUAGE SELECT ================= */

const languageCodes = {
  English: "en-US",
  Urdu: "ur-PK",
  Hindi: "hi-IN",
  Arabic: "ar-SA",
  Spanish: "es-ES",
  German: "de-DE",
  French: "fr-FR"
};

document
  .querySelectorAll(".language-option")
  .forEach(option => {

    option.onclick = () => {

      const language = option.dataset.lang;

      selectedLanguage =
        languageCodes[language] || "en-US";

      languageBtn.textContent = "🌐";

      closeLanguageMenu();

      typingBox.focus();

      console.log("Language:", language);
    };

  });

/* ================= CLOSE MENU ================= */

document.addEventListener("click", event => {

  if (
    !languageMenu.contains(event.target) &&
    event.target !== languageBtn &&
    event.target !== languageKey
  ) {
    closeLanguageMenu();
  }

});

/* ================= SUGGESTIONS ================= */

document
  .querySelectorAll(".suggestion")
  .forEach(button => {

    button.onclick = () => {
      insertText(button.textContent + " ");
    };

  });

/* ================= CLEAR ================= */

clearBtn.onclick = () => {

  typingBox.value = "";

  typingBox.focus();
};

/* ================= COPY ================= */

copyBtn.onclick = async () => {

  if (!typingBox.value) return;

  try {

    await navigator.clipboard.writeText(
      typingBox.value
    );

    copyBtn.textContent = "✓";

    setTimeout(() => {
      copyBtn.textContent = "📋";
    }, 1000);

  } catch {

    typingBox.select();
    document.execCommand("copy");
    typingBox.setSelectionRange(
      typingBox.value.length,
      typingBox.value.length
    );
  }

  typingBox.focus();
};

/* ================= NUMBER / ABC ================= */

numberKey.onclick = () => {

  numberMode = !numberMode;

  const keys =
    document.querySelectorAll(".key");

  keys.forEach((button, index) => {

    button.textContent =
      numberMode
        ? numbers[index]
        : alphabet[index];

  });

  numberKey.textContent =
    numberMode ? "ABC" : "123";

  if (numberMode) {
    shiftActive = false;
    shiftKey.classList.remove("active");
  }
};

/* ================= VOICE ================= */

let recognition = null;
let listening = false;

const SpeechRecognition =
  window.SpeechRecognition ||
  window.webkitSpeechRecognition;

if (SpeechRecognition) {

  recognition = new SpeechRecognition();

  recognition.continuous = false;
  recognition.interimResults = false;

  recognition.lang = selectedLanguage;

  recognition.onstart = () => {

    listening = true;
    voiceBtn.textContent = "🔴";
  };

  recognition.onresult = event => {

    const text =
      event.results[0][0].transcript;

    insertText(
      (typingBox.value ? " " : "") + text
    );
  };

  recognition.onerror = event => {

    listening = false;
    voiceBtn.textContent = "🎤";

    if (event.error === "not-allowed") {

      alert(
        "Microphone permission denied. Browser settings میں Microphone کو Allow کریں، پھر دوبارہ Voice دبائیں۔"
      );

    } else {

      console.log(
        "Voice error:",
        event.error
      );
    }
  };

  recognition.onend = () => {

    listening = false;
    voiceBtn.textContent = "🎤";
  };

  voiceBtn.onclick = () => {

    if (listening) {

      recognition.stop();
      return;
    }

    recognition.lang = selectedLanguage;

    try {
      recognition.start();
    } catch (error) {
      console.log(error);
    }
  };

} else {

  voiceBtn.onclick = () => {

    alert(
      "Voice typing اس browser میں supported نہیں ہے۔ Chrome یا supported browser استعمال کریں۔"
    );

  };

}

/* ================= START ================= */

typingBox.focus();